import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registered-users',
  templateUrl: './registered-users.component.html',
  styleUrls: ['./registered-users.component.scss']
})
export class RegisteredUsersComponent implements OnInit {

  users=[
    {
      name:'Mohit Patel',
      img:'assets/images/avatar/1.jpg',
      email:'mohitpatel@gmail.com',
      lastlogin:'22/12/2019',
      regdate:'10/12/2019'
    },
    {
      name:'Mohit Patel',
      img:'assets/images/avatar/1.jpg',
      email:'mohitpatel@gmail.com',
      lastlogin:'22/12/2019',
      regdate:'10/12/2019'
    },
    {
      name:'Mohit Patel',
      img:'assets/images/avatar/1.jpg',
      email:'mohitpatel@gmail.com',
      lastlogin:'22/12/2019',
      regdate:'10/12/2019'
    },
    {
      name:'Mohit Patel',
      img:'assets/images/avatar/1.jpg',
      email:'mohitpatel@gmail.com',
      lastlogin:'22/12/2019',
      regdate:'10/12/2019'
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
