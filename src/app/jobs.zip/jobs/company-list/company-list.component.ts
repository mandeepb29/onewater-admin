import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.scss']
})
export class CompanyListComponent implements OnInit {

  companies=[
    {
      name:'DigiX',
      category:'Digital Solutions',
      address:'Los Angeles',
      img:'assets/images/avatar/1.jpg'

    },
    {
      name:'DigiX',
      category:'Digital Solutions',
      address:'Los Angeles',
      img:'assets/images/avatar/1.jpg'
    },
    {
      name:'DigiX',
      category:'Digital Solutions',
      address:'Los Angeles',
      img:'assets/images/avatar/1.jpg'
    },
    {
      name:'DigiX',
      category:'Digital Solutions',
      address:'Los Angeles',
      img:'assets/images/avatar/1.jpg'
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
