import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JobsRoutingModule } from './jobs-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    JobsRoutingModule
  ]
})
export class JobsModule { }
