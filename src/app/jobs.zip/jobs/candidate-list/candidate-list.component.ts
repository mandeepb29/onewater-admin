import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.scss']
})
export class CandidateListComponent implements OnInit {


  candidates=[
    {
      name:'Mandeep Baghel',
      address:'Indore , India',
      currentPos:'Web Designer',
      img:'assets/images/avatar/1.jpg'
    },
    {
      name:'Mandeep Baghel',
      address:'Indore , India',
      currentPos:'Web Designer',
      img:'assets/images/avatar/1.jpg'
    },
    {
      name:'Mandeep Baghel',
      address:'Indore , India',
      currentPos:'Web Designer',
      img:'assets/images/avatar/1.jpg'
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
